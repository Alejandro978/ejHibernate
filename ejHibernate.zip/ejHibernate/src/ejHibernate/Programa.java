package ejHibernate;

import java.util.Date;

import org.hibernate.Session;

public class Programa {

	public static void main(String[] args) {
		anyadirEmpresa();
		anyadirItem();
		anyadirPedido();
		
		
	}

	public static void anyadirEmpresa() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		
		empresa e1 = new empresa(123,"fffff",23,"alejandro");
		
		session.save(e1);

	
		session.getTransaction().commit();
		session.close();
	}

	public static void anyadirItem() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		item i1 = new item();

		i1.setNombre("Item1");
		i1.setCantidad(50);

		session.save(i1);

		
		session.getTransaction().commit();
		session.close();
	}

	public static void anyadirPedido() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		pedido p1 = new pedido();

		p1.setFecha(new Date());

		session.save(p1);

		
		session.getTransaction().commit();
		session.close();
	}

	public static void recuperarEmpresa() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		empresa e1 = session.get(empresa.class, 1);

		System.out.println("Hemos encontrado : CIF: " + e1.getCIF() + " con nombre " + e1.getNombre() + " en direcci�n "
				+ e1.getDireccion() + "su n�mero de empleados es: " + e1.getEmpleados());

		
		session.getTransaction().commit();
		session.close();
	}

	public static void recuperarItem() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		item i1 = session.get(item.class, 1);

		System.out.println("Nombre producto: " + i1.getNombre() + " cantidad : " + i1.getCantidad());

	
		session.getTransaction().commit();
		session.close();
	}
	
	public static void recuperarPedido() {
		Session session = HibernateUtilities.getSessionFactory().openSession();
		session.beginTransaction();
		pedido p1 = session.get(pedido.class,1);

		System.out.println("Fecha pedido: " + p1.getFecha());

		
		session.getTransaction().commit();
		session.close();
	}

}
