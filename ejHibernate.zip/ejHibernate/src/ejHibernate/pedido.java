package ejHibernate;

import java.util.Date;

public class pedido {
	
public int id;
public Date fecha;

public pedido() {}

public pedido(int id, Date fecha) {
	this.id = id;
	this.fecha = fecha;
}

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public Date getFecha() {
	return fecha;
}
public void setFecha(java.util.Date fecha) {
	this.fecha = (Date) fecha;
}

}
