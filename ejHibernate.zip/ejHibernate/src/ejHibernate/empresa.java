package ejHibernate;

public class empresa {
	

	public int CIF;
	public String nombre;
	public int empleados;
	public String direccion;
	
	public empresa () {}
	public empresa(int CIF, String nombre, int empleados, String direccion) {
		this.CIF = CIF;
		this.nombre = nombre;
		this.empleados = empleados;
		this.direccion = direccion;
	}
	
	
	public int getCIF() {
		return CIF;
	}
	public void setCIF(int cIF) {
		CIF = cIF;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public int getEmpleados() {
		return empleados;
	}
	public void setEmpleados(int empleados) {
		this.empleados = empleados;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

}
